<?php

?>
    <link type="text/css" rel="stylesheet" href="../Public/CSS/searchbar.css"/>

<div id="search-bar">
    <img src="../Public/Images/Search-Icon.png" alt="Search" id="search-icon"/>
    <input id="search-text-box" type="text" placeholder="Search Foods">
</div>
<div class="search-result"></div>
<div id = "resultDiv"> </div>
<script src="../Public/JS/jquery-3.3.1.js"></script>
<script src="../Public/JS/searchbar.js"></script>

