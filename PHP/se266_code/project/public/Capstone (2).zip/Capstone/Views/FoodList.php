
<link type="text/css" rel="stylesheet" href="../Public/CSS/FoodList.css"/>
<div id="content">
    
</div>
<script src="../Public/JS/jquery-3.3.1.js"></script>
<script src="../Public/JS/FoodList.js"></script>