<link type="text/css" rel="stylesheet" href="../Public/CSS/logout.css"/>
<form id="logout" method="post" action="../Controllers/MainController.php"><button type="submit" name="action" value="Logout"></button> </form>

