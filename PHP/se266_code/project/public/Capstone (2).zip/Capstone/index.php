<?php

header("Location:Controllers/MainController.php");
