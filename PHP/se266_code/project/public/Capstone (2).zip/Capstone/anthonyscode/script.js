function sidebar()
{
    document.getElementById("sidebar")
}