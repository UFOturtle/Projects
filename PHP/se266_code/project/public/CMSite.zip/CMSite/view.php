
<form method="post" action="controller.php">

      <h3>CM Viewer </h3><br>
      <p>Select What you want to see to get started.</p>
      <button type="submit" name="view" value="listCustomers">List Customers</button>
      <button type="submit" name="view" value="listEmployees">List Employees</button>
      <button type="submit" name="view" value="listOrders">List Orders</button>
      <button type="submit" name="view" value="listTopCustomers">List Top Customers</button>
      <button type="submit" name="view" value="listUselessCustomers">List Useless Customers</button>
      <button type="submit" name="view" value="listCustomersByCountry">List Customers Customers By Country</button>
      <button type="submit" name="view" value="listProducts">List Products</button>
 </form>



