<?php
//refreshes the controller after a case is done
header("../Controllers/MainController.php");