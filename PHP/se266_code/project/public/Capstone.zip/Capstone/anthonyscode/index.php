<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.bundle.min.js"></script>
    <?php
    if(isset($_SESSION['isLoggedIn'])) 
    {
        if( $_SESSION['isLoggedIn'] == false ) 
        {
            header('Location: http://ict.neit.edu/001408918/Capstone/LACalorie/Capstone/capstone/login.php');
        }
        else 
        {
            // Do Nothing
        }
    } 
    else 
    {
        // header('Location: http://localhost/LACalorie/Capstone/capstone/login.php');
    }
    ?>
</head>

<body>
        <div class="wrapper">
                <!-- Sidebar -->
                <nav id="sidebar">
                   
                <!--    <div class="sidebar-header">
                        <h3>Bootstrap Sidebar</h3>
                    </div>  -->
            
                    <ul class="list-unstyled components">
                        <p>Username</p>
                        <li>
                            <p class="xx" href="#">Name</p>
                        </li>
                        <li class="active">
                            <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Age</a>
                            <ul class="collapse list-unstyled" id="homeSubmenu">
                                <li>
                                    <p class="xx">Home 1</p>
                                </li>
                                <li>
                                    <p class="xx">Home 2</p>
                                </li>
                                <li>
                                    <p class="xx">Home 3</p>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <p class="xx">Gender</p>
                        </li>
                       <!--  <li>
                            <p href="#">Weight</p>
                        </li> -->
                        <li>
                            <p class="xx">Goal</p>
                        </li>
                        <li>
                            <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Height</a>
                            <ul class="collapse list-unstyled" id="pageSubmenu">
                                <li>
                                    <p href="#">Page 1</p>
                                </li>
                                <li>
                                    <p href="#">Page 2</p>
                                </li>
                                <li>
                                    <p href="#">Page 3</p>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <p href="#">Wants To</p>
                        </li>
                        <li>
                            <p href="#">Calorie Goal</p>
                        </li>
                    </ul>

                    <div class="col-md-5">
                        <canvas id="myChart"></canvas>
                    </div>

                    <div class="col-md-5">
                        <canvas id="lineChart"></canvas>
                    </div>

                     <div class="logout">
                        <a href="login.php">Logout</a>
                    </div>

                </nav>
            
            
            <div id="content">
                    <nav class="navbar navbar-expand-lg navbar-light bg-light">
                        <div class="container-fluid">
                
                            <button type="button" id="sidebarCollapse" class="btn">
                                <i class="fa fa-bars"></i>
                                <span></span>
                            </button>
                
                        </div>
                    </nav>
            </div> 

            <!--Search Bar-->
            <div class="searchBar">
                <input type="text" placeholder="Search">
            </div>
        </div>

        <div class="calendar">
                
        </div>
        <div class="foodList">
            
        </div>  

     <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>


    <script>
        $(document).ready(function(){
           $("#sidebarCollapse").on('click', function () {
               $('#sidebar').toggleClass('active');
           });

           $("#bonk").on('click', function () {
               $('#sidebar').toggleClass('active');
           });
        });
    </script>
    
    

    <script>
        var ctx = document.getElementById("myChart").getContext('2d');
        var myChart = new Chart(ctx, {
          type: 'bar',
          data: {
            labels: ["Yellow", "Yellow", "Yellow", "Purple", "Purple", "Purple"],
            datasets: [{
              label: '# of Calories',
              data: [12, 19, 3, 5, 10, 15],
              backgroundColor: [
                'rgba(153, 102, 255, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(153, 102, 255, 0.2)'
              ],
              borderColor: [
                'rgba(153, 102, 255, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(153, 102, 255, 1)'
              ],
              borderWidth: 1
            }]
          },
          options: {
            scales: {
              yAxes: [{
                ticks: {
                  beginAtZero: true
                }
              }]
            }
          }
        });
    </script>

    <script>
        var ctx = document.getElementById("lineChart").getContext('2d');
        var lineChart = new Chart(ctx, {
          type: 'line',
          data: {
            labels: ["Red", "Blue", "Yellow", "Green", "Purple", "Orange"],
            datasets: [{
              label: 'Weekly Weight',
              data: [12, 19, 3, 5, 2, 3],
              backgroundColor: [
                'rgba(255, 206, 86, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 206, 86, 0.2)'
              ],
              borderColor: [
                'rgba(255, 206, 86, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 206, 86, 1)'
              ],
              borderWidth: 1
            }]
          },
          options: {
            scales: {
              yAxes: [{
                ticks: {
                  beginAtZero: true
                }
              }]
            }
          }
        });
    </script>
</body>
</html>