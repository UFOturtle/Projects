<?php
include'../Models/MySQLQueries/MysqlQueries.php';
//$Profile = Get_Profile("Leezus1");
//echo $Profile[0]['caloriegoal'];

//$CalorieEntry = Get_Calories('Leezus1', date("y/m/d") );
//var_dump($CalorieEntry);
 //$Item = Get_FItem(3);
 //var_dump($Item[0]["foodname"]);
 var_dump(Get_WeekData('9'));
/*
<script>
    var xmlhttp = new XMLHttpRequest();
      var myjson=[];
      xmlhttp.open('GET', '../Models/MYSQLQueries/MYSQLQueries.php?gday=' + encodeURIComponent(gday));
      xmlhttp.send();
      
      
      xmlhttp.onreadystatechange = function() {
        if (this.readyState === 4 && this.status === 200) {
        //display.innerHTML = this.responseText;

         var myjson = JSON.parse(this.responseText);
         
         console.log(myjson);
</script>
*/