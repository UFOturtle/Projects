
    <link type="text/css" rel="stylesheet" href="../Public/CSS/calendar.css"/>
    <div id="calendar">
        <nav id = "calendar-nav"> 
            <img id="leftarrow" src="../Public/Images/arrow.png" alt="back">
            <h2 id="year">Year</h2> 
            <h1 id="month">Month</h1> 
            <img src="../Public/Images/arrow.png" alt="forward" id="rightarrow">
        </nav>
        <br>
        <div id="weekdays"><h3>S</h3><h3>M</h3><h3>T</h3><h3>W</h3><h3>T</h3><h3>F</h3><h3>S</h3></div>
        <br>
        <div id ="days">

        </div>
        <div id = "resultDiv"> </div>
        

    </div>
    <link type="text/css" rel="stylesheet" href="../Public/CSS/FoodList.css"/>
    <div id="content">
    
    </div>
    <!--<script src="../Public/JS/jquery-3.4.1.slim.js"></script>-->
    <script src="../Public/JS/jquery-3.3.1.js"></script>
    <script src="/Capstone/Public/JS/calendar.js"></script>

